import React, { useState, useRef } from 'react';
import AudioRecorder from './components/AudioRecorder';
import { transcribeAudio, evaluateQuiz, generateQuestionsFromEssay } from './services/geminiService';
import { AppState, TranscriptionResponse, EvaluationResult } from './types';

interface QuestionResult extends TranscriptionResponse {
  question: string;
  questionIndex: number;
}

const App: React.FC = () => {
  const [appState, setAppState] = useState<AppState>(AppState.UPLOAD);
  const [questions, setQuestions] = useState<string[]>([]);
  const [essayText, setEssayText] = useState<string>("");
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [allResults, setAllResults] = useState<QuestionResult[]>([]);
  const [error, setError] = useState<string | null>(null);
  const [evaluationResult, setEvaluationResult] = useState<EvaluationResult | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileUpload = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    if (file.type !== 'text/plain') {
      setError("Please upload a valid .txt file.");
      return;
    }

    const reader = new FileReader();
    reader.onload = async (e) => {
      const text = e.target?.result as string;
      setEssayText(text);
      setAppState(AppState.GENERATING_QUESTIONS);
      setError(null);

      try {
        const generatedQuestions = await generateQuestionsFromEssay(text);
        setQuestions(generatedQuestions);
        setAppState(AppState.IDLE);
      } catch (err) {
        console.error(err);
        setError("Failed to generate questions from the essay.");
        setAppState(AppState.UPLOAD);
      }
    };
    reader.onerror = () => {
      setError("Failed to read file.");
    };
    reader.readAsText(file);
  };

  const handleRecordingComplete = async (audioBlob: Blob) => {
    setAppState(AppState.PROCESSING);
    setError(null);

    try {
      // Convert Blob to Base64
      const reader = new FileReader();
      reader.readAsDataURL(audioBlob);
      reader.onloadend = async () => {
        const base64String = reader.result as string;
        const base64Content = base64String.split(',')[1];
        const mimeType = audioBlob.type;

        try {
          const transcription = await transcribeAudio(base64Content, mimeType);
          
          const resultWithContext: QuestionResult = {
            ...transcription,
            question: questions[currentQuestionIndex],
            questionIndex: currentQuestionIndex + 1
          };

          const updatedResults = [...allResults, resultWithContext];
          setAllResults(updatedResults);

          if (currentQuestionIndex < questions.length - 1) {
            setCurrentQuestionIndex(prev => prev + 1);
            setAppState(AppState.IDLE);
          } else {
            // Last question finished, auto-evaluate
            setAppState(AppState.EVALUATING);
            try {
              const evalResult = await evaluateQuiz(updatedResults, essayText);
              setEvaluationResult(evalResult);
              setAppState(AppState.COMPLETED);
            } catch (evalError) {
              console.error("Evaluation failed", evalError);
              setError("Quiz submitted, but automatic grading failed.");
              setAppState(AppState.COMPLETED); // Allow user to see results even if grading fails
            }
          }

        } catch (apiError) {
          console.error(apiError);
          setError("Failed to transcribe audio. Please try again.");
          setAppState(AppState.ERROR);
        }
      };
      reader.onerror = () => {
        setError("Failed to process audio file locally.");
        setAppState(AppState.ERROR);
      };
    } catch (e) {
      console.error(e);
      setError("An unexpected error occurred.");
      setAppState(AppState.ERROR);
    }
  };

  const resetQuiz = () => {
    setAllResults([]);
    setQuestions([]);
    setEssayText("");
    setCurrentQuestionIndex(0);
    setAppState(AppState.UPLOAD);
    setEvaluationResult(null);
    setError(null);
    if (fileInputRef.current) {
        fileInputRef.current.value = "";
    }
  };

  const downloadJson = () => {
    const exportData = {
      essay: essayText,
      session_results: allResults,
      evaluation: evaluationResult || undefined
    };
    
    const dataStr = JSON.stringify(exportData, null, 2);
    const blob = new Blob([dataStr], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = 'essay_quiz_results.json';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  const isEvaluating = appState === AppState.EVALUATING;
  const isQuizComplete = appState === AppState.COMPLETED;
  const isUploading = appState === AppState.UPLOAD;
  const isGenerating = appState === AppState.GENERATING_QUESTIONS;
  const showRecorder = !isEvaluating && !isQuizComplete && !isUploading && !isGenerating;

  const currentQuestion = questions[currentQuestionIndex];

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col items-center py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-3xl w-full space-y-8 bg-white p-8 rounded-2xl shadow-xl border border-slate-100">
        <div className="text-center space-y-2">
          <div className="inline-flex items-center justify-center p-3 bg-indigo-100 rounded-xl mb-4">
             <span className="text-2xl" role="img" aria-label="book">📚</span>
          </div>
          <h2 className="text-3xl font-extrabold text-slate-900 tracking-tight">
            Essay Knowledge Check
          </h2>
          <p className="text-slate-500 text-sm">
            Powered by Gemini 3.0 Pro & 2.5 Flash
          </p>
        </div>

        {isUploading && (
          <div className="space-y-6 animate-fade-in">
            <div className="bg-slate-50 border-2 border-dashed border-slate-300 rounded-xl p-10 text-center hover:border-indigo-400 transition-colors">
              <div className="space-y-4">
                <svg className="mx-auto h-12 w-12 text-slate-400" stroke="currentColor" fill="none" viewBox="0 0 48 48" aria-hidden="true">
                  <path d="M28 8H12a4 4 0 00-4 4v20m32-12v8m0 0v8a4 4 0 01-4 4H12a4 4 0 01-4-4v-4m32-4l-3.172-3.172a4 4 0 00-5.656 0L28 28M8 32l9.172-9.172a4 4 0 015.656 0L28 28m0 0l4 4m4-24h8m-4-4v8m-12 4h.02" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
                </svg>
                <div className="text-sm text-slate-600">
                  <label htmlFor="file-upload" className="relative cursor-pointer rounded-md font-medium text-indigo-600 hover:text-indigo-500 focus-within:outline-none focus-within:ring-2 focus-within:ring-offset-2 focus-within:ring-indigo-500">
                    <span>Upload your essay.txt</span>
                    <input 
                        id="file-upload" 
                        name="file-upload" 
                        type="file" 
                        className="sr-only" 
                        accept=".txt"
                        ref={fileInputRef}
                        onChange={handleFileUpload}
                    />
                  </label>
                  <p className="pl-1 inline">to generate a quiz</p>
                </div>
                <p className="text-xs text-slate-500">
                  TXT files only
                </p>
              </div>
            </div>
            <p className="text-center text-sm text-slate-500">
              Gemini will analyze your essay and generate 3 questions to test your understanding.
            </p>
          </div>
        )}

        {isGenerating && (
           <div className="py-16 text-center space-y-4 animate-pulse">
             <div className="mx-auto flex items-center justify-center w-16 h-16 rounded-full bg-indigo-100">
                <svg className="animate-spin h-8 w-8 text-indigo-600" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                  <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                  <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                </svg>
             </div>
             <h3 className="text-xl font-bold text-slate-700">Analyzing Essay...</h3>
             <p className="text-slate-500">Generating insightful questions from your text.</p>
          </div>
        )}

        {showRecorder && (
          <>
            <div className="space-y-4">
              <div className="flex justify-between items-center text-sm font-medium text-slate-400 uppercase tracking-wider">
                <span>Question {currentQuestionIndex + 1} of {questions.length}</span>
                <div className="flex space-x-1">
                  {questions.map((_, idx) => (
                    <div 
                      key={idx} 
                      className={`h-2 w-2 rounded-full transition-colors duration-300 ${idx === currentQuestionIndex ? 'bg-indigo-600' : idx < currentQuestionIndex ? 'bg-indigo-200' : 'bg-slate-200'}`}
                    />
                  ))}
                </div>
              </div>

              <div className="bg-indigo-50 border border-indigo-100 rounded-xl p-6 text-center min-h-[160px] flex flex-col justify-center items-center transition-all duration-500">
                <h3 className="text-xl font-semibold text-indigo-900 mb-2">Current Question:</h3>
                <p className="text-2xl text-indigo-700 font-bold">
                  "{currentQuestion}"
                </p>
              </div>
            </div>

            <div className="py-6 flex justify-center">
              <AudioRecorder 
                key={currentQuestionIndex}
                onRecordingComplete={handleRecordingComplete} 
                isProcessing={appState === AppState.PROCESSING}
              />
            </div>
          </>
        )}

        {isEvaluating && (
          <div className="py-16 text-center space-y-4 animate-pulse">
             <div className="mx-auto flex items-center justify-center w-16 h-16 rounded-full bg-indigo-100">
                <svg className="animate-spin h-8 w-8 text-indigo-600" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                  <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                  <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                </svg>
             </div>
             <h3 className="text-xl font-bold text-slate-700">Grading your quiz...</h3>
             <p className="text-slate-500">Comparing your answers against the essay.</p>
          </div>
        )}

        {isQuizComplete && (
          <div className="space-y-8 animate-fade-in">
             <div className="text-center">
                <h3 className="text-2xl font-bold text-emerald-600 mb-2">Results</h3>
                <p className="text-slate-600">Here is your performance report.</p>
             </div>

            {/* Evaluation Report Card */}
            {evaluationResult ? (
              <div className="bg-white border-2 border-indigo-100 rounded-xl overflow-hidden shadow-sm">
                <div className="bg-indigo-50 px-6 py-4 border-b border-indigo-100 flex justify-between items-center">
                  <h4 className="font-bold text-indigo-900 flex items-center gap-2">
                    <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"></path></svg>
                    Teacher's Report
                  </h4>
                  <div className="text-sm font-mono font-bold bg-white px-3 py-1 rounded-full text-indigo-600 shadow-sm">
                    Score: {evaluationResult.totalScore} / {evaluationResult.maxScore}
                  </div>
                </div>
                <div className="p-6 space-y-6">
                  <p className="text-slate-700 italic border-l-4 border-indigo-300 pl-4 py-1 bg-slate-50 rounded-r">
                    "{evaluationResult.summary}"
                  </p>
                  
                  <div className="space-y-4">
                    {evaluationResult.details.map((detail, idx) => {
                      const originalResult = allResults.find(r => r.questionIndex === detail.questionIndex);
                      return (
                        <div key={idx} className={`p-4 rounded-lg border ${detail.isCorrect ? 'border-green-200 bg-green-50' : 'border-red-200 bg-red-50'}`}>
                          <div className="flex justify-between items-start mb-2">
                            <span className="font-semibold text-slate-700 text-sm">Q{detail.questionIndex}: {originalResult?.question}</span>
                            <span className={`text-xs font-bold px-2 py-0.5 rounded ${detail.isCorrect ? 'bg-green-200 text-green-800' : 'bg-red-200 text-red-800'}`}>
                              {detail.score}/10
                            </span>
                          </div>
                          <div className="text-sm text-slate-600 mb-2">
                            <span className="font-medium">Your Answer:</span> {originalResult?.transcription}
                          </div>
                          <div className="text-sm">
                             <span className="font-medium text-slate-900">Feedback: </span> 
                             <span className={detail.isCorrect ? 'text-green-700' : 'text-red-700'}>{detail.feedback}</span>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>
              </div>
            ) : (
               <div className="p-6 text-center bg-orange-50 border border-orange-200 rounded-xl text-orange-800">
                  <p>Evaluation data is unavailable. Please download the raw results to check your answers.</p>
               </div>
            )}
            
            <div className="flex flex-col sm:flex-row gap-3">
              <button
                 onClick={downloadJson}
                 className="flex-1 flex justify-center items-center py-3 px-4 border border-transparent rounded-xl shadow-sm text-sm font-bold text-white bg-emerald-600 hover:bg-emerald-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-emerald-500 transition-all transform hover:scale-[1.02]"
              >
                <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4" />
                </svg>
                Download Report
              </button>
              
              <button
                 onClick={resetQuiz}
                 className="flex-1 flex justify-center items-center py-3 px-4 border border-slate-300 rounded-xl shadow-sm text-sm font-bold text-slate-700 bg-white hover:bg-slate-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 transition-all"
              >
                Upload New Essay
              </button>
            </div>
          </div>
        )}

        {error && (
          <div className="rounded-md bg-red-50 p-4 border border-red-200 animate-pulse">
            <div className="flex">
              <div className="flex-shrink-0">
                <svg className="h-5 w-5 text-red-400" viewBox="0 0 20 20" fill="currentColor">
                  <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM8.707 7.293a1 1 0 00-1.414 1.414L8.586 10l-1.293 1.293a1 1 0 101.414 1.414L10 11.414l1.293 1.293a1 1 0 001.414-1.414L11.414 10l1.293-1.293a1 1 0 00-1.414-1.414L10 8.586 8.707 7.293z" clipRule="evenodd" />
                </svg>
              </div>
              <div className="ml-3">
                <h3 className="text-sm font-medium text-red-800">Error</h3>
                <div className="mt-2 text-sm text-red-700">
                  <p>{error}</p>
                </div>
                <button 
                  onClick={() => {
                    setError(null);
                    if (appState === AppState.ERROR) {
                        setAppState(AppState.IDLE);
                    }
                  }}
                  className="mt-2 text-sm font-medium text-red-600 hover:text-red-500 underline"
                >
                  Dismiss
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default App;