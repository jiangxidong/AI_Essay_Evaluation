import { GoogleGenAI, Type } from "@google/genai";
import { TranscriptionResponse, EvaluationResult } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export const generateQuestionsFromEssay = async (essayText: string): Promise<string[]> => {
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-pro-preview',
      contents: {
        parts: [
          {
            text: `Use this prompt to check if a student truly understands and wrote their essay: Ask them, “You wrote about [KEY CONCEPT]. Explain it in your own words to someone new to the topic,” and “You used the term ‘[TECHNICAL TERM].’ What does it mean here, and why does it matter?” Then ask, “How did you develop your main argument from first idea to final thesis?” and “What was the hardest part of writing this essay, and how did you handle it?” For sources, ask, “You cited [SPECIFIC SOURCE]. How did you find it, and why did you decide to use it?” Check critical thinking with, “If you rewrote this essay, what would you change and why?” and “What’s the strongest counterargument to your thesis, and how would you respond?” Test application with, “Give a real-world example where your main ideas would apply,” or “Imagine [HYPOTHETICAL SCENARIO]. How would your argument apply there?” Finally, ask, “In 30 seconds, what’s the single most important idea in your essay, and why is it important?”

            
            
            ESSAY CONTENT:
            ${essayText}
            
            Return the output as a JSON array of strings containing exactly 3 questions.`
          }
        ]
      },
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.ARRAY,
          items: { type: Type.STRING }
        }
      }
    });

    const text = response.text;
    if (!text) throw new Error("No questions generated");
    return JSON.parse(text) as string[];
  } catch (error) {
    console.error("Error generating questions:", error);
    throw error;
  }
};

export const transcribeAudio = async (base64Audio: string, mimeType: string): Promise<TranscriptionResponse> => {
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-pro-preview',
      contents: {
        parts: [
          {
            inlineData: {
              mimeType: mimeType,
              data: base64Audio
            }
          },
          {
            text: "Transcribe the audio accurately. Return the result in JSON format."
          }
        ]
      },
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            transcription: {
              type: Type.STRING,
              description: "The transcribed text from the audio."
            },
            confidenceScore: {
              type: Type.NUMBER,
              description: "A confidence score between 0 and 1."
            },
            detectedLanguage: {
              type: Type.STRING,
              description: "The detected language code (e.g., en-US)."
            }
          },
          required: ["transcription"]
        }
      }
    });

    const text = response.text;
    if (!text) {
        throw new Error("No response text from Gemini");
    }
    return JSON.parse(text) as TranscriptionResponse;
  } catch (error) {
    console.error("Error calling Gemini API:", error);
    throw error;
  }
};

export const evaluateQuiz = async (quizData: any[], essayText: string): Promise<EvaluationResult> => {
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-pro-preview',
      contents: {
        parts: [
          {
             text: `You are a helpful and fair teacher. Evaluate the following quiz answers provided by a student based on the provided source essay.

             SOURCE ESSAY:
             ${essayText}
             
             STUDENT QUIZ DATA:
             ${JSON.stringify(quizData)}
             
            TASK:
            Evaluate the student's answer on a scale of 0-10 points based on:
            1. Accuracy: Does the answer align with the source essay?
            2. Depth: Does the answer show deep understanding of the essay?
            3. Consistency: Does the answer align with the essay's arguments?

              Provide:
              - Score: [0-10]
              - Brief rationale (50 words): Explain the score.
              - Is Correct: Boolean based on whether they understood the core concept.

             Return the output as a structured JSON object.
             `
          }
        ]
      },
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            totalScore: { type: Type.NUMBER, description: "Sum of all scores obtained." },
            maxScore: { type: Type.NUMBER, description: "The maximum possible score (number of questions * 10)." },
            summary: { type: Type.STRING, description: "A brief overall summary of the student's performance." },
            details: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  questionIndex: { type: Type.NUMBER, description: "The index of the question (1-based)." },
                  isCorrect: { type: Type.BOOLEAN },
                  score: { type: Type.NUMBER, description: "Score out of 10" },
                  feedback: { type: Type.STRING }
                },
                required: ["questionIndex", "isCorrect", "score", "feedback"]
              }
            }
          },
          required: ["totalScore", "maxScore", "summary", "details"]
        }
      }
    });

    const text = response.text;
    if (!text) {
      throw new Error("No evaluation returned from Gemini");
    }
    return JSON.parse(text) as EvaluationResult;

  } catch (error) {
    console.error("Error evaluating quiz:", error);
    throw error;
  }
};