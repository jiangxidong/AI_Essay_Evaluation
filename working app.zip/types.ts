export interface TranscriptionResponse {
  transcription: string;
  confidenceScore?: number;
  detectedLanguage?: string;
}

export enum AppState {
  UPLOAD = 'UPLOAD',
  GENERATING_QUESTIONS = 'GENERATING_QUESTIONS',
  IDLE = 'IDLE',
  RECORDING = 'RECORDING',
  PROCESSING = 'PROCESSING',
  EVALUATING = 'EVALUATING',
  COMPLETED = 'COMPLETED',
  ERROR = 'ERROR'
}

export interface AudioConfig {
  sampleRate: number;
  mimeType: string;
}

export interface EvaluationDetail {
  questionIndex: number;
  isCorrect: boolean;
  score: number; // 0 to 10
  feedback: string;
}

export interface EvaluationResult {
  totalScore: number; // Sum of scores
  maxScore: number;
  summary: string;
  details: EvaluationDetail[];
}