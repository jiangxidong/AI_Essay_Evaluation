import React from 'react';
import { Link } from 'react-router-dom';

export const InterviewFeedbackView = () => {
  return (
    <div className="min-h-screen bg-background-light flex items-center justify-center p-4">
        <div className="bg-white rounded-xl shadow-lg p-8 max-w-md w-full text-center">
            <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4 text-primary">
                <span className="material-symbols-outlined text-3xl">schedule</span>
            </div>
            <h1 className="text-2xl font-bold text-gray-900 mb-2">Feedback Pending Review</h1>
            <p className="text-text-secondary mb-8">Your professor is reviewing your interview. You'll receive a notification when feedback is available.</p>
            
            <div className="space-y-4 mb-8">
                <div className="flex items-center gap-4 text-left">
                    <div className="w-10 h-10 rounded-full bg-green-100 flex items-center justify-center text-green-600 shrink-0">
                        <span className="material-symbols-outlined">done</span>
                    </div>
                    <p className="text-gray-700">Interview submitted on October 26th</p>
                </div>
                 <div className="flex items-center gap-4 text-left">
                    <div className="w-10 h-10 rounded-full bg-blue-50 flex items-center justify-center text-blue-500 shrink-0 animate-pulse">
                        <span className="material-symbols-outlined">hourglass_top</span>
                    </div>
                    <p className="text-gray-700">Under review</p>
                </div>
            </div>

            <Link to="/student/dashboard" className="block w-full py-3 border border-primary text-primary font-medium rounded-lg hover:bg-blue-50 transition-colors">
                Return to Dashboard
            </Link>
        </div>
    </div>
  );
};
