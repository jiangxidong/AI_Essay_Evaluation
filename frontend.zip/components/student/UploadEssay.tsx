import React from 'react';
import { Link } from 'react-router-dom';

export const UploadEssay = () => {
  return (
    <div className="min-h-screen bg-background-light dark:bg-background-dark flex flex-col">
       <header className="flex items-center justify-between border-b border-border-light dark:border-border-dark bg-white dark:bg-gray-800 px-6 py-4">
        <div className="flex items-center gap-3">
          <Link to="/student/dashboard" className="text-primary">
            <span className="material-symbols-outlined text-2xl">arrow_back</span>
          </Link>
          <h1 className="text-xl font-bold text-text-primary dark:text-white">VeritasCheck</h1>
        </div>
        <div className="flex items-center gap-4">
            <span className="text-sm font-medium text-text-primary dark:text-white">Alex Johnson</span>
            <div className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center text-primary font-bold text-xs">AJ</div>
        </div>
      </header>

      <main className="flex-1 flex items-center justify-center p-6">
        <div className="w-full max-w-2xl">
          <div className="flex flex-col items-center gap-6 rounded-xl border-2 border-dashed border-gray-300 dark:border-gray-700 bg-white dark:bg-gray-800/50 px-6 py-20 text-center hover:bg-gray-50 dark:hover:bg-gray-800 transition-colors cursor-pointer group">
            <div className="w-16 h-16 bg-blue-50 dark:bg-blue-900/20 rounded-full flex items-center justify-center group-hover:scale-110 transition-transform">
               <span className="material-symbols-outlined text-4xl text-primary">upload_file</span>
            </div>
            
            <div className="space-y-2">
              <h2 className="text-2xl font-medium text-text-primary dark:text-white">Drag & Drop Your Essay Here</h2>
              <p className="text-text-secondary dark:text-gray-400">or click the button below to browse files</p>
            </div>

            <button className="px-8 py-3 bg-primary hover:bg-blue-600 text-white rounded-lg font-medium shadow-sm transition-colors">
              Upload Essay
            </button>

            <p className="text-xs text-text-secondary dark:text-gray-500">Supported formats: .txt, .docx, .pdf. Maximum file size: 10MB</p>
          </div>
        </div>
      </main>
    </div>
  );
};
