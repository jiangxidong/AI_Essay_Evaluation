import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';

export const InterviewScreen = () => {
  const [status, setStatus] = useState<'loading' | 'active' | 'complete'>('loading');

  useEffect(() => {
    // Simulate loading
    const timer = setTimeout(() => {
      setStatus('active');
    }, 2500);
    return () => clearTimeout(timer);
  }, []);

  const handleFinish = () => {
    setStatus('complete');
  };

  // 1. Loading State
  if (status === 'loading') {
    return (
      <div className="min-h-screen bg-gradient-to-b from-white to-[#F0F7FF] dark:from-background-dark dark:to-gray-900 flex flex-col items-center justify-center p-6">
        <div className="w-full max-w-md bg-white dark:bg-gray-800 rounded-xl shadow-lg border border-border-light dark:border-border-dark p-10 text-center">
          <div className="w-20 h-20 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-6">
            <span className="material-symbols-outlined text-5xl text-primary">psychology</span>
          </div>
          <h1 className="text-2xl font-semibold text-text-primary dark:text-white mb-4">Generating Your Interview Questions</h1>
          <div className="flex flex-col items-center gap-3">
            <div className="flex items-center gap-2 text-text-secondary dark:text-gray-400">
              <p>Analyzing your essay</p>
              <div className="flex gap-1">
                <span className="w-1 h-1 bg-current rounded-full animate-bounce"></span>
                <span className="w-1 h-1 bg-current rounded-full animate-bounce [animation-delay:0.2s]"></span>
                <span className="w-1 h-1 bg-current rounded-full animate-bounce [animation-delay:0.4s]"></span>
              </div>
            </div>
            <div className="w-full h-2 bg-gray-100 dark:bg-gray-700 rounded-full overflow-hidden mt-2">
              <div className="h-full bg-primary w-1/2 animate-[pulse_1.5s_ease-in-out_infinite]"></div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  // 2. Complete State
  if (status === 'complete') {
    return (
      <div className="min-h-screen bg-background-light dark:bg-background-dark flex flex-col items-center justify-center p-4">
        <div className="w-full max-w-lg bg-white dark:bg-gray-800 rounded-xl shadow-sm p-8 text-center border border-border-light dark:border-border-dark">
          <div className="w-16 h-16 bg-green-100 dark:bg-green-900/30 rounded-full flex items-center justify-center mx-auto mb-6">
            <span className="material-symbols-outlined text-4xl text-green-600 dark:text-green-400">check_circle</span>
          </div>
          <h3 className="text-2xl font-bold text-text-primary dark:text-white mb-2">Interview Complete!</h3>
          <p className="text-text-secondary dark:text-gray-400 mb-6">Your responses have been submitted for review.</p>
          
          <div className="flex items-start gap-4 bg-blue-50 dark:bg-blue-900/20 p-4 rounded-lg text-left mb-6">
            <span className="material-symbols-outlined text-blue-600 dark:text-blue-400 mt-0.5">schedule</span>
            <p className="text-sm text-text-primary dark:text-gray-200">Your professor will review your interview and provide feedback within 3-5 business days.</p>
          </div>

          <Link to="/student/dashboard" className="block w-full py-3 bg-primary hover:bg-blue-600 text-white rounded-lg font-medium transition-colors">
            Return to Dashboard
          </Link>
        </div>
      </div>
    );
  }

  // 3. Active Interview State
  return (
    <div className="min-h-screen bg-background-light dark:bg-background-dark flex flex-col">
       <header className="flex items-center justify-between border-b border-border-light dark:border-border-dark bg-white dark:bg-gray-800 px-6 py-3">
        <div className="flex items-center gap-3">
          <span className="material-symbols-outlined text-primary text-2xl">school</span>
          <h2 className="font-bold text-lg dark:text-white">Veritas Academic</h2>
        </div>
        <div className="w-10 h-10 rounded-full bg-cover bg-center" style={{backgroundImage: 'url("https://lh3.googleusercontent.com/aida-public/AB6AXuB0LlQLkaIZI5VWcuh7xyzxeXZNPyZiuaHnL4-HMIJpfCcG6dCFDpXHQm4u7MLevuecnhxXHLIdBWlFKAEId75R2GpoGk_3bZC_YcJyL_oq5SSHt0MNowPTBJV3bDWm52I7KaA7f7UMmEriRWTwPJ5UdbcKzoANL-egXEKjtLFGqCs8mxAQjheeyRGcvQVJ0d1ocniTAmjySKlYdZetvpd4SUCpnDeY5HlLBFcjAhCK0ZiWtLBfq0hoJl2i14VfJa8GeAXAxxZDwech")'}}></div>
      </header>

      <main className="flex-1 flex items-center justify-center p-4">
        <div className="w-full max-w-4xl flex flex-col items-center gap-10">
          <div className="w-full max-w-3xl bg-white dark:bg-gray-800 rounded-xl shadow-sm p-8 border border-border-light dark:border-border-dark">
            <p className="text-sm text-text-secondary dark:text-gray-400 mb-4">Question 1 of 5</p>
            <h2 className="text-xl font-medium text-text-primary dark:text-white leading-relaxed">
              Can you describe a challenging academic project you worked on and explain how you overcame the obstacles you faced?
            </h2>
          </div>

          <div className="flex flex-col items-center gap-6">
            <p className="text-text-secondary dark:text-gray-400 animate-pulse">60 seconds remaining</p>
            
            <button 
              onClick={handleFinish}
              className="w-20 h-20 rounded-full bg-primary hover:bg-blue-600 text-white flex items-center justify-center shadow-xl shadow-primary/30 transition-transform active:scale-95 group relative"
            >
              <span className="absolute inset-0 rounded-full bg-primary opacity-30 animate-ping"></span>
              <span className="material-symbols-outlined text-4xl">mic</span>
            </button>

            <div className="flex gap-3">
              <div className="w-3 h-3 rounded-full bg-primary"></div>
              <div className="w-3 h-3 rounded-full bg-gray-300 dark:bg-gray-700"></div>
              <div className="w-3 h-3 rounded-full bg-gray-300 dark:bg-gray-700"></div>
              <div className="w-3 h-3 rounded-full bg-gray-300 dark:bg-gray-700"></div>
              <div className="w-3 h-3 rounded-full bg-gray-300 dark:bg-gray-700"></div>
            </div>
            <button onClick={handleFinish} className="text-sm text-text-secondary hover:text-primary underline">Skip (Demo)</button>
          </div>
        </div>
      </main>
    </div>
  );
};
