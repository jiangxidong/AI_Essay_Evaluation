import React from 'react';
import { Link } from 'react-router-dom';

export const FeedbackView = () => {
  return (
    <div className="min-h-screen bg-background-light dark:bg-background-dark flex flex-col">
       <header className="flex items-center justify-between border-b border-border-light dark:border-border-dark bg-white dark:bg-gray-800 px-6 py-4">
        <div className="flex items-center gap-4">
           <Link to="/student/dashboard" className="text-primary flex items-center gap-1 hover:bg-blue-50 dark:hover:bg-gray-700 px-2 py-1 rounded transition-colors">
              <span className="material-symbols-outlined">arrow_back</span>
              <span className="font-medium">Dashboard</span>
           </Link>
           <h1 className="text-lg font-bold text-text-primary dark:text-white border-l border-border-light dark:border-border-dark pl-4 ml-2">History 101: Mid-term Paper</h1>
        </div>
        <div className="w-10 h-10 rounded-full bg-cover bg-center border border-gray-200" style={{backgroundImage: 'url("https://lh3.googleusercontent.com/aida-public/AB6AXuB0LlQLkaIZI5VWcuh7xyzxeXZNPyZiuaHnL4-HMIJpfCcG6dCFDpXHQm4u7MLevuecnhxXHLIdBWlFKAEId75R2GpoGk_3bZC_YcJyL_oq5SSHt0MNowPTBJV3bDWm52I7KaA7f7UMmEriRWTwPJ5UdbcKzoANL-egXEKjtLFGqCs8mxAQjheeyRGcvQVJ0d1ocniTAmjySKlYdZetvpd4SUCpnDeY5HlLBFcjAhCK0ZiWtLBfq0hoJl2i14VfJa8GeAXAxxZDwech")'}}></div>
      </header>

      <main className="flex-1 p-4 md:p-10 max-w-5xl mx-auto w-full">
        <div className="mb-8">
           <h2 className="text-3xl font-bold text-text-primary dark:text-white mb-2">History 101: Mid-term Paper</h2>
           <p className="text-text-secondary dark:text-gray-400">View feedback on your submission</p>
        </div>

        <div className="bg-white dark:bg-gray-800 rounded-lg border border-border-light dark:border-border-dark p-6 mb-8 grid md:grid-cols-3 gap-6 shadow-sm">
          <div className="md:col-span-1 md:border-r border-border-light dark:border-gray-700">
             <p className="text-sm text-text-secondary dark:text-gray-400 mb-1">Essay Title</p>
             <p className="font-medium text-text-primary dark:text-white">The Geopolitical Implications of Post-War Reconstruction</p>
          </div>
          <div>
             <p className="text-sm text-text-secondary dark:text-gray-400 mb-1">Submission Date</p>
             <p className="font-medium text-text-primary dark:text-white">October 26, 2023, 11:59 PM</p>
          </div>
           <div>
             <p className="text-sm text-text-secondary dark:text-gray-400 mb-1">Interview Completion Date</p>
             <p className="font-medium text-text-primary dark:text-white">October 28, 2023, 02:30 PM</p>
          </div>
        </div>

        <div className="bg-yellow-50 dark:bg-yellow-900/10 border border-yellow-200 dark:border-yellow-900/30 rounded-lg p-8 shadow-sm">
          <div className="flex items-center gap-4 mb-6">
             <div className="w-12 h-12 rounded-full bg-cover bg-center" style={{backgroundImage: 'url("https://lh3.googleusercontent.com/aida-public/AB6AXuDNo_WfTK-GfNyxKUsIqlh7p_6mVDtH1SN87jDJ4cVemt1OdK8RIpnqqxuY_SY92mvM2t_3JdchM4vNQHFK4jEf21J9JwnW2k7VRrbn9L9_zDq7z_pFerxKfF9Gp0W6q-RAb--pw_GfG2CSkJ-pPPiCUx7NKJGCLQKy2BOSYQfGR2L8RZ_bOqo2ZDYKIEBSIPpz3YU8QfLCtKFI7g8OAovy4AuEUBwNGVJ_aKlOuAXlaBuH1xnNn_YqeP2NtbfdP5M1AfCrleFEZOLR")'}}></div>
             <div>
               <h3 className="text-lg font-bold text-gray-900 dark:text-yellow-100">Professor Feedback</h3>
               <p className="text-sm text-gray-600 dark:text-yellow-200/70">Dr. Eleanor Vance</p>
             </div>
          </div>
          <div className="pt-4 border-t border-yellow-200 dark:border-yellow-900/30">
            <p className="text-lg text-gray-800 dark:text-yellow-100 leading-relaxed">
              This is a thoughtful analysis of the primary sources. You've done an excellent job contrasting the economic policies of the two periods. However, the section on cultural impact could be strengthened with more specific examples. Consider exploring the influence of post-war cinema as a reflection of societal shifts. Your conclusion is strong, but try to tie it back more explicitly to your initial thesis. Overall, a very solid effort with clear potential. I look forward to seeing your revisions.
            </p>
          </div>
        </div>
      </main>
    </div>
  );
};
