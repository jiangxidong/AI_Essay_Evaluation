import React from 'react';
import { Link } from 'react-router-dom';
import { Assignment } from '../../types';

const assignments: Assignment[] = [
  {
    id: '1',
    courseCode: 'PHIL 101',
    title: 'The Ethics of AI in Modern Society',
    dueDate: 'October 22, 2023',
    status: 'overdue',
    interviewStatus: 'not-scheduled',
  },
  {
    id: '2',
    courseCode: 'ART 205',
    title: 'Renaissance Art and its Cultural Impact',
    dueDate: 'October 18, 2023',
    status: 'feedback-available',
  },
  {
    id: '3',
    courseCode: 'PHYS 310',
    title: 'The Role of Quantum Mechanics in Computing',
    dueDate: 'October 28, 2023',
    status: 'submitted',
    interviewStatus: 'pending',
  },
  {
    id: '4',
    courseCode: 'BUS 450',
    title: 'Supply Chain Management in the Digital Age',
    dueDate: 'November 1, 2023',
    status: 'submitted',
    interviewStatus: 'complete',
  },
  {
    id: '5',
    courseCode: 'ECON 301',
    title: 'Behavioral Economics and Public Policy',
    dueDate: 'November 5, 2023',
    status: 'not-started',
  }
];

export const StudentDashboard = () => {
  return (
    <div className="min-h-screen flex flex-col bg-background-light dark:bg-background-dark">
      {/* Header */}
      <header className="bg-white dark:bg-gray-800 border-b border-border-light dark:border-border-dark px-4 sm:px-8 py-3 sticky top-0 z-10">
        <div className="max-w-5xl mx-auto flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Link to="/" className="text-primary">
              <span className="material-symbols-outlined text-3xl">school</span>
            </Link>
            <h1 className="text-lg font-bold text-text-primary dark:text-white">EssayVerifier</h1>
          </div>
          <div className="flex items-center gap-4">
            <button className="p-2 rounded-full bg-gray-100 dark:bg-gray-700 hover:bg-gray-200">
              <span className="material-symbols-outlined text-gray-600 dark:text-gray-300">notifications</span>
            </button>
            <div className="w-10 h-10 rounded-full bg-cover bg-center border border-gray-200" style={{backgroundImage: 'url("https://lh3.googleusercontent.com/aida-public/AB6AXuB0LlQLkaIZI5VWcuh7xyzxeXZNPyZiuaHnL4-HMIJpfCcG6dCFDpXHQm4u7MLevuecnhxXHLIdBWlFKAEId75R2GpoGk_3bZC_YcJyL_oq5SSHt0MNowPTBJV3bDWm52I7KaA7f7UMmEriRWTwPJ5UdbcKzoANL-egXEKjtLFGqCs8mxAQjheeyRGcvQVJ0d1ocniTAmjySKlYdZetvpd4SUCpnDeY5HlLBFcjAhCK0ZiWtLBfq0hoJl2i14VfJa8GeAXAxxZDwech")'}}></div>
          </div>
        </div>
      </header>

      {/* Content */}
      <main className="flex-1 p-4 sm:p-8">
        <div className="max-w-5xl mx-auto space-y-8">
          <div className="flex justify-between items-end">
            <div>
              <h1 className="text-3xl font-bold text-text-primary dark:text-white">Hi, Alex</h1>
              <p className="text-text-secondary dark:text-gray-400 mt-1">Monday, October 23, 2023</p>
            </div>
          </div>

          <div className="space-y-4">
            {assignments.map((assignment) => (
              <div key={assignment.id} className="bg-white dark:bg-gray-800 rounded-lg p-6 border border-border-light dark:border-border-dark shadow-sm flex flex-col sm:flex-row gap-4 justify-between items-start sm:items-center">
                <div className="space-y-2 flex-1">
                  <h3 className="text-lg font-semibold text-text-primary dark:text-white">{assignment.title}</h3>
                  <p className="text-sm text-text-secondary dark:text-gray-400">{assignment.courseCode}</p>
                  <div className="flex items-center gap-2 text-sm text-text-secondary dark:text-gray-400">
                    <span className="material-symbols-outlined text-base">calendar_today</span>
                    <span>Due: {assignment.dueDate}</span>
                  </div>

                  <div className="pt-1">
                    {assignment.status === 'overdue' && (
                      <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-medium bg-red-100 text-red-700 dark:bg-red-900/30 dark:text-red-300">
                        <span className="material-symbols-outlined text-sm">error</span> Overdue
                      </span>
                    )}
                    {assignment.status === 'feedback-available' && (
                      <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-medium bg-green-100 text-green-700 dark:bg-green-900/30 dark:text-green-300">
                        <span className="relative flex h-2 w-2">
                          <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-green-400 opacity-75"></span>
                          <span className="relative inline-flex rounded-full h-2 w-2 bg-green-500"></span>
                        </span>
                        Feedback Available
                      </span>
                    )}
                    {assignment.interviewStatus === 'pending' && (
                      <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-medium bg-blue-100 text-blue-700 dark:bg-blue-900/30 dark:text-blue-300">
                        <span className="material-symbols-outlined text-sm">mic</span> Essay Submitted - Interview Pending
                      </span>
                    )}
                     {assignment.interviewStatus === 'complete' && (
                      <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-medium bg-blue-50 text-blue-600 dark:bg-blue-900/20 dark:text-blue-400">
                         <span className="material-symbols-outlined text-sm animate-pulse-subtle">hourglass_top</span> Interview Complete - Awaiting Feedback
                      </span>
                    )}
                    {assignment.status === 'not-started' && (
                      <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-medium bg-gray-100 text-gray-700 dark:bg-gray-700 dark:text-gray-300">
                        Not Started
                      </span>
                    )}
                  </div>
                </div>

                <div className="w-full sm:w-auto">
                  {assignment.status === 'overdue' && (
                    <Link to="/student/upload" className="flex items-center justify-center w-full sm:w-auto px-6 py-2 bg-gray-100 hover:bg-gray-200 text-gray-700 rounded-lg text-sm font-medium transition-colors">
                      Submit Late
                    </Link>
                  )}
                  {assignment.status === 'feedback-available' && (
                    <Link to="/student/feedback/essay" className="flex items-center justify-center w-full sm:w-auto px-6 py-2 bg-primary hover:bg-blue-600 text-white rounded-lg text-sm font-medium transition-colors">
                      View Feedback
                    </Link>
                  )}
                  {assignment.interviewStatus === 'pending' && (
                    <Link to="/student/interview" className="flex items-center justify-center w-full sm:w-auto px-6 py-2 bg-primary hover:bg-blue-600 text-white rounded-lg text-sm font-medium transition-colors">
                      Begin Interview
                    </Link>
                  )}
                  {assignment.status === 'not-started' && (
                     <Link to="/student/upload" className="flex items-center justify-center w-full sm:w-auto px-6 py-2 bg-gray-900 hover:bg-black text-white rounded-lg text-sm font-medium transition-colors dark:bg-white dark:text-gray-900">
                      Start Assignment
                    </Link>
                  )}
                   {assignment.interviewStatus === 'complete' && (
                     <button disabled className="flex items-center justify-center w-full sm:w-auto px-6 py-2 bg-gray-100 text-gray-400 rounded-lg text-sm font-medium cursor-not-allowed">
                      Awaiting Feedback
                    </button>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>
      </main>
    </div>
  );
};
