import React, { useState } from 'react';
import { Link } from 'react-router-dom';

export const FeedbackEditor = () => {
    const [showModal, setShowModal] = useState(false);

  return (
    <div className="min-h-screen bg-background-light flex overflow-hidden">
      {/* Sidebar */}
      <aside className="w-64 bg-white border-r border-gray-200 flex flex-col shrink-0">
        <div className="p-6">
           <div className="flex items-center gap-3 mb-6">
              <div className="text-primary"><span className="material-symbols-outlined">school</span></div>
              <h2 className="font-bold text-gray-800">EssayComprehend</h2>
           </div>
           <nav className="space-y-1">
             <Link to="/professor/dashboard" className="flex items-center gap-3 px-3 py-2 text-gray-600 hover:bg-gray-50 rounded-lg">
                <span className="material-symbols-outlined">dashboard</span>
                <span className="text-sm font-medium">Dashboard</span>
             </Link>
             <div className="flex items-center gap-3 px-3 py-2 bg-blue-50 text-primary rounded-lg">
                <span className="material-symbols-outlined font-bold">assignment_turned_in</span>
                <span className="text-sm font-bold">Submissions</span>
             </div>
           </nav>
        </div>
      </aside>

      {/* Main Content */}
      <div className="flex-1 flex flex-col h-screen">
         <header className="h-16 border-b border-gray-200 bg-white flex items-center justify-between px-8 shrink-0">
            <div className="flex-1"></div>
            <div className="flex gap-3">
               <button className="px-4 py-2 bg-gray-100 text-gray-700 font-medium rounded-lg hover:bg-gray-200 text-sm">Save as Draft</button>
               <button onClick={() => setShowModal(true)} className="px-4 py-2 bg-primary text-white font-medium rounded-lg hover:bg-blue-600 text-sm">Submit Feedback</button>
            </div>
         </header>

         <main className="flex-1 overflow-hidden flex flex-col p-8">
            <div className="mb-6">
               <h1 className="text-2xl font-bold text-gray-900">Feedback for John Doe - Thematic Analysis of 'The Great Gatsby'</h1>
               <p className="text-gray-500">Review the AI-generated draft and add your final comments before submission.</p>
            </div>

            <div className="flex-1 flex flex-col border border-gray-200 rounded-lg bg-white overflow-hidden">
               {/* AI Section */}
               <div className="flex-[3] flex flex-col border-b border-gray-200">
                  <div className="flex items-center justify-between p-3 border-b border-gray-100 bg-gray-50">
                     <div className="flex items-center gap-3">
                        <span className="px-2 py-0.5 bg-blue-100 text-blue-700 text-xs font-bold rounded uppercase">AI Draft</span>
                        <h3 className="font-medium text-gray-700">AI-Generated Feedback</h3>
                     </div>
                     <div className="flex gap-2 text-gray-400">
                        <span className="material-symbols-outlined text-sm cursor-pointer hover:text-gray-600">format_bold</span>
                        <span className="material-symbols-outlined text-sm cursor-pointer hover:text-gray-600">format_italic</span>
                     </div>
                  </div>
                  <div className="flex-1 p-4 bg-blue-50/30 overflow-y-auto">
                     <textarea className="w-full h-full bg-transparent border-0 resize-none focus:ring-0 text-gray-700 leading-relaxed text-sm" defaultValue="John, this is a strong initial analysis of the thematic elements in 'The Great Gatsby'. Your exploration of the American Dream's corruption is well-argued, particularly in your discussion of Gatsby's unattainable desires. You've correctly identified key symbols like the green light and the eyes of Dr. T.J. Eckleburg.&#10;&#10;To elevate this essay, consider delving deeper into the contrast between 'old money' (the Buchanans) and 'new money' (Gatsby). How does this social divide reinforce the novel's central themes? Furthermore, expanding on Daisy's role as both an object of desire and a symbol of the dream's emptiness would add significant depth. Your conclusion could be strengthened by summarizing these points more forcefully. Overall, a commendable effort that shows a clear understanding of the text."></textarea>
                  </div>
                  <div className="px-4 py-2 text-right text-xs text-gray-400 border-t border-gray-100">340 / 800</div>
               </div>

               {/* Divider */}
               <div className="h-8 flex items-center justify-center bg-gray-50 border-b border-gray-200">
                  <div className="h-px bg-gray-300 w-full mx-4"></div>
                  <span className="text-xs font-bold text-gray-400 uppercase tracking-wider px-2 whitespace-nowrap">Your Input</span>
                  <div className="h-px bg-gray-300 w-full mx-4"></div>
               </div>

               {/* User Section */}
               <div className="flex-[2] flex flex-col">
                  <div className="p-3 border-b border-gray-100 bg-gray-50">
                     <h3 className="font-medium text-gray-700">Your Additional Comments</h3>
                  </div>
                  <div className="flex-1 p-4">
                     <textarea className="w-full h-full border-0 focus:ring-0 resize-none text-gray-700 text-sm placeholder:text-gray-400" placeholder="Add your personal notes or final comments here..."></textarea>
                  </div>
               </div>
            </div>
         </main>
      </div>

      {/* Modal */}
      {showModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4">
          <div className="w-full max-w-[500px] bg-white rounded-lg shadow-xl overflow-hidden animate-[scale_0.2s_ease-out]">
            <div className="p-6">
              <h2 className="text-xl font-bold text-gray-900 mb-2">Review & Send</h2>
              <p className="text-sm text-text-secondary">This is a scrollable preview of the complete feedback that will be sent to the student.</p>
            </div>
            
            <div className="max-h-64 overflow-y-auto border-y border-gray-100 px-6 py-4 bg-gray-50/50">
               <div className="space-y-4 text-sm text-gray-800">
                  <div>
                    <h3 className="font-semibold text-gray-900 mb-1">Overall Summary</h3>
                    <p className="text-gray-600">Excellent work on the core arguments of your essay. You've clearly identified the primary sources and drawn insightful connections...</p>
                  </div>
                  <div>
                    <h3 className="font-semibold text-gray-900 mb-1">Inline Comments</h3>
                    <div className="pl-3 border-l-2 border-primary space-y-2">
                        <div>
                            <span className="font-medium text-gray-900 block">Page 2, Paragraph 3:</span>
                            <span className="italic text-gray-500">"This is a good point, but can you elaborate..."</span>
                        </div>
                    </div>
                  </div>
               </div>
            </div>

            <div className="p-6 bg-white">
                <p className="text-sm text-gray-600 mb-4">This feedback will be sent to John Doe.</p>
                <div className="flex justify-end gap-3">
                    <button onClick={() => setShowModal(false)} className="px-4 py-2 border border-gray-300 rounded-lg text-gray-700 font-medium hover:bg-gray-50">Go Back</button>
                    <button onClick={() => setShowModal(false)} className="px-4 py-2 bg-primary text-white rounded-lg font-medium hover:bg-blue-600">Confirm Send</button>
                </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
