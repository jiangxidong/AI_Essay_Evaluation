import React from 'react';
import { Link } from 'react-router-dom';

const students = [
  {
    name: 'Eleanor Vance',
    avatar: 'https://lh3.googleusercontent.com/aida-public/AB6AXuALC5GfS9xF_2vMZRRGNOjdZ006gewfHZ5jIr1DTOoMqfg0zoqyyLzBcgXpSNtmgpZnd038p6MLdpDoYUO2pETmV_E0UG-egPwsc0BfOQiHXtU9-jcwoRvE2QYk2Ag_XHU8Y0QYpryPT3SJIWrm_rEJdGP2tj0aTC36mthvhdnh7kz6TbD0u1N0rEBdMMWj2PxeWCrDYd_QdQ12Hkj--TfXzzWwDw3LrpZ_ePWjXxLo4EBu0l681byTq8yUrUyUSa7s8VKcUJ2enThf',
    status: 'Submitted',
    statusColor: 'green',
    interview: 'Scheduled',
    interviewColor: 'blue',
    score: 85,
    reviewStatus: 'Pending Review',
    reviewColor: 'yellow',
    id: '1'
  },
  {
    name: 'Marcus Holloway',
    avatar: 'https://lh3.googleusercontent.com/aida-public/AB6AXuByHGyBIagMk5D6xvvRrlyINsvx3ku8CLIg7E-dVqnSaH_VtpW3Jbfvcx8BX408l6lhrpa1SwbyzOnajY1tsCE_W1fXINFknHHAFYDT_IDu9fFWDVWcaWahp7uq-TP1YDh2-VWWLVcX2BADGkKE_-z2_fx-uQif5LwMEGmprL3Mkl_JhYG8mX5ncuCPwaf0j-TL1C4qsWWCIdpeHljG6_wkbQMluJ6aD6Z25cMMQAd6qhKmFWh97nKa46Vx_VFgevClsanInz-lboxB',
    status: 'Submitted',
    statusColor: 'green',
    interview: 'Not Scheduled',
    interviewColor: 'gray',
    score: 42,
    reviewStatus: 'Graded',
    reviewColor: 'green',
    id: '2'
  },
  {
    name: 'Jenna Ortega',
    avatar: 'https://lh3.googleusercontent.com/aida-public/AB6AXuAOX5iVgyBvpVZ6H_9uQdf5ZH93PJmSHucb4aBI7H-6GFRod8AfoFZUz65a5tXKabKlM_gWccExqgWLBEXDtvRiYS8xvp58zVMPvG0Z8BS-1ulTJMORfShwOgjxpjDkSEsAxbVQOmiiQ3TCOLQgIDkEvEu5Pbzraz-L-4iOzijDH4seQdZPOy9Z0OoJYaot9lZAkG-kJh54-I3AvVHq5y5lPwhYMjoMu8hhzVfLBl4VnUmYILLn5wvMbnwrGfW1KI9wW4lT72OmfWhY',
    status: 'Late',
    statusColor: 'red',
    interview: 'Not Scheduled',
    interviewColor: 'gray',
    score: 68,
    reviewStatus: 'Pending Review',
    reviewColor: 'yellow',
    id: '3'
  },
  {
    name: 'Alex Johnson',
    avatar: 'https://lh3.googleusercontent.com/aida-public/AB6AXuBkPaCbeTYIO-fA6Dh5zT2ddjiXKoTgVbvnOuPuArAuzfqWPPtOS9UgITsIIwoZ9s9atETe7tlBPfDKXqC5kJIO70iKEwHU6aAVppsPogeD4-Y5MEO-uRzSF2fXNSgsKFk_q388iJdd1YfID5DbjrUJ3sSYQBDM4xdUau3cbuLe-QGsS5gGaPPYJX20nlVSUm7sBbqvucmVMf73ZySCvGLl-4UX-M5WaewRApj_ZBhW1G2YqKcsBNl0IV0_DZudjRl-J0AtTRt9SRMS',
    status: 'Submitted',
    statusColor: 'green',
    interview: 'Scheduled',
    interviewColor: 'blue',
    score: 92,
    reviewStatus: 'Graded',
    reviewColor: 'green',
    id: '4'
  }
];

export const CourseView = () => {
  return (
    <div className="min-h-screen bg-background-light text-text-primary">
       <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="flex items-center gap-4 mb-6">
           <Link to="/professor/dashboard" className="h-10 w-10 flex items-center justify-center bg-white border border-gray-200 rounded-full hover:bg-gray-50">
             <span className="material-symbols-outlined text-gray-600">arrow_back</span>
           </Link>
           <div>
              <h1 className="text-2xl font-bold text-gray-900">Analysis of Renaissance Literature</h1>
              <p className="text-sm text-text-secondary">Course Code: ENG-301</p>
           </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
           <div className="bg-white p-6 rounded-lg border border-gray-200 flex items-center gap-4">
              <span className="material-symbols-outlined text-3xl text-gray-400">calendar_month</span>
              <div>
                 <p className="text-sm text-text-secondary font-medium">Due Date</p>
                 <p className="text-lg font-semibold text-gray-900">Oct 26, 2024</p>
              </div>
           </div>
           <div className="bg-white p-6 rounded-lg border border-gray-200 flex items-center gap-4">
              <span className="material-symbols-outlined text-3xl text-gray-400">assignment_turned_in</span>
              <div>
                 <p className="text-sm text-text-secondary font-medium">Total Submissions</p>
                 <p className="text-lg font-semibold text-gray-900">23/25</p>
              </div>
           </div>
        </div>

        <div className="bg-white rounded-lg border border-gray-200 overflow-hidden shadow-sm">
           <div className="overflow-x-auto">
             <table className="w-full text-sm text-left">
               <thead className="bg-gray-50 text-xs uppercase text-gray-500 font-medium">
                  <tr>
                    <th className="px-6 py-4">Student Name</th>
                    <th className="px-6 py-4">Submission Status</th>
                    <th className="px-6 py-4">Interview Status</th>
                    <th className="px-6 py-4">Review Status</th>
                    <th className="px-6 py-4 text-right">Actions</th>
                  </tr>
               </thead>
               <tbody className="divide-y divide-gray-200">
                  {students.map((student) => (
                    <tr key={student.id} className="hover:bg-gray-50">
                       <td className="px-6 py-4">
                          <div className="flex items-center gap-3">
                             <img src={student.avatar} alt={student.name} className="w-8 h-8 rounded-full object-cover"/>
                             <span className="font-medium text-gray-900">{student.name}</span>
                          </div>
                       </td>
                       <td className="px-6 py-4">
                          <span className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-medium bg-${student.statusColor}-100 text-${student.statusColor}-800`}>
                             <span className={`w-1.5 h-1.5 rounded-full bg-${student.statusColor}-500`}></span>
                             {student.status}
                          </span>
                       </td>
                       <td className="px-6 py-4">
                          <span className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-medium bg-${student.interviewColor === 'gray' ? 'gray-200' : student.interviewColor + '-100'} text-${student.interviewColor === 'gray' ? 'gray-700' : student.interviewColor + '-800'}`}>
                             <span className={`w-1.5 h-1.5 rounded-full bg-${student.interviewColor === 'gray' ? 'gray-400' : student.interviewColor + '-500'}`}></span>
                             {student.interview}
                          </span>
                       </td>
                       <td className="px-6 py-4">
                          <span className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-medium bg-${student.reviewColor}-100 text-${student.reviewColor}-800`}>
                             <span className={`w-1.5 h-1.5 rounded-full bg-${student.reviewColor}-500`}></span>
                             {student.reviewStatus}
                          </span>
                       </td>
                       <td className="px-6 py-4 text-right">
                          <div className="flex justify-end gap-2">
                             <Link to={`/professor/grade/${student.id}`} className="h-8 w-8 flex items-center justify-center rounded hover:bg-gray-100 text-gray-500">
                               <span className="material-symbols-outlined text-base">visibility</span>
                             </Link>
                             <Link to={`/professor/edit-feedback/${student.id}`} className="h-8 w-8 flex items-center justify-center rounded hover:bg-gray-100 text-gray-500">
                               <span className="material-symbols-outlined text-base">rate_review</span>
                             </Link>
                          </div>
                       </td>
                    </tr>
                  ))}
               </tbody>
             </table>
           </div>
        </div>
       </div>
    </div>
  );
};