import React from 'react';
import { Link } from 'react-router-dom';

export const ProfessorDashboard = () => {
  return (
    <div className="min-h-screen bg-background-light text-text-primary">
      <header className="bg-white border-b border-border-light px-8 h-20 flex items-center justify-between">
         <div className="flex items-center gap-4">
            <span className="material-symbols-outlined text-primary text-3xl">school</span>
            <h1 className="text-xl font-bold">Assessment Platform</h1>
         </div>
         <nav className="hidden md:flex items-center gap-8">
            <a href="#" className="text-sm font-medium text-primary">Dashboard</a>
            <a href="#" className="text-sm font-medium text-text-secondary hover:text-primary">Assignments</a>
            <a href="#" className="text-sm font-medium text-text-secondary hover:text-primary">Settings</a>
         </nav>
         <div className="flex items-center gap-4">
           <button className="p-2 hover:bg-gray-100 rounded-full text-text-secondary">
             <span className="material-symbols-outlined">notifications</span>
           </button>
            <div className="w-10 h-10 rounded-full bg-cover bg-center" style={{backgroundImage: 'url("https://lh3.googleusercontent.com/aida-public/AB6AXuDCXNQgGXjxVNxyd1WW3l7ZmI_7SVKZ0Tj90OX1Aqh8YYdwVIvq4EsPJtVTY3XKjHU2lrNUoazvPeQoK4EtFukueRgQX_BQIZL2R_DuaBfbbqUqHCETIDRfO9yNVQQtWRDCJdmJ3G4oSs6W77Zv5roEapt42dLGcFZdVnTkQ56-_x1kA1EXpCBUuEwzmY4LDcag7JC6lVlBV11l68ncMVq34-Ko80Dvzoqrp9WKL2x2ok-OljGm0i1QVodJ5oJ8gUpKCEd1quuANANw")'}}></div>
         </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="flex flex-wrap items-center justify-between gap-4 border-b border-gray-200 pb-6 mb-8">
           <div>
             <h2 className="text-3xl font-bold text-gray-900">Welcome back, Professor Evans</h2>
             <p className="text-text-secondary mt-1">Tuesday, October 24, 2023</p>
           </div>
           <button className="flex items-center gap-2 bg-primary hover:bg-blue-600 text-white px-5 py-2.5 rounded-lg font-medium transition-colors">
              <span className="material-symbols-outlined text-xl">add</span> New Assignment
           </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
           {/* Card 1 */}
           <div className="bg-white rounded-lg border border-gray-200 p-6 shadow-sm">
              <p className="text-sm text-text-secondary mb-1">ENG-101</p>
              <h3 className="text-lg font-medium text-gray-900 mb-4">Analysis of Modernist Literature</h3>
              <div className="flex items-baseline gap-2 mb-4">
                <span className="text-3xl font-bold text-primary">23</span>
                <span className="text-gray-500">/ 25 Submitted</span>
              </div>
              <div className="mb-6">
                 <span className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-orange-100 text-orange-600 text-sm font-medium">
                   <span className="w-2 h-2 rounded-full bg-orange-500"></span> 5 Pending Review
                 </span>
              </div>
              <div className="pt-4 border-t border-gray-100">
                <Link to="/professor/course/ENG-101" className="block w-full text-center py-2 border-2 border-primary text-primary rounded-lg font-medium hover:bg-primary hover:text-white transition-colors">
                  View Details
                </Link>
              </div>
           </div>

           {/* Card 2 */}
           <div className="bg-white rounded-lg border border-gray-200 p-6 shadow-sm">
              <p className="text-sm text-text-secondary mb-1">LIT-202</p>
              <h3 className="text-lg font-medium text-gray-900 mb-4">Shakespearean Sonnets Essay</h3>
              <div className="flex items-baseline gap-2 mb-4">
                <span className="text-3xl font-bold text-primary">18</span>
                <span className="text-gray-500">/ 20 Submitted</span>
              </div>
              <div className="mb-6">
                 <span className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-orange-100 text-orange-600 text-sm font-medium">
                   <span className="w-2 h-2 rounded-full bg-orange-500"></span> 2 Pending Review
                 </span>
              </div>
              <div className="pt-4 border-t border-gray-100">
                <button className="block w-full text-center py-2 border-2 border-primary text-primary rounded-lg font-medium hover:bg-primary hover:text-white transition-colors">
                  View Details
                </button>
              </div>
           </div>

           {/* Card 3 */}
           <div className="bg-white rounded-lg border border-gray-200 p-6 shadow-sm">
              <p className="text-sm text-text-secondary mb-1">ENG-101</p>
              <h3 className="text-lg font-medium text-gray-900 mb-4">The Great Gatsby: Critical Review</h3>
              <div className="flex items-baseline gap-2 mb-4">
                <span className="text-3xl font-bold text-primary">25</span>
                <span className="text-gray-500">/ 25 Submitted</span>
              </div>
              <div className="mb-6">
                 <span className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-green-100 text-green-600 text-sm font-medium">
                   <span className="w-2 h-2 rounded-full bg-green-500"></span> All Graded
                 </span>
              </div>
              <div className="pt-4 border-t border-gray-100">
                <button className="block w-full text-center py-2 border-2 border-primary text-primary rounded-lg font-medium hover:bg-primary hover:text-white transition-colors">
                  View Details
                </button>
              </div>
           </div>
        </div>
      </main>
    </div>
  );
};
