import React from 'react';
import { Link } from 'react-router-dom';

export const InterviewReview = () => {
  return (
    <div className="min-h-screen bg-gray-50 flex">
       {/* Simple Sidebar for this view */}
       <aside className="w-1/4 max-w-sm bg-white border-r border-gray-200 p-8 flex flex-col gap-8 fixed h-full overflow-y-auto">
          <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6 flex flex-col items-center text-center">
             <div className="w-24 h-24 rounded-full bg-cover bg-center mb-4" style={{backgroundImage: 'url("https://lh3.googleusercontent.com/aida-public/AB6AXuAIwoid1ykF6SFYYd83L04ACFzx2NUvHnv-TXx-0vATtlGHSwxJgUc3NZarr_4OgAigeWx0qvHXRu7UYBNTzknIRDmBlICCOPQsWOl3Zr8VRJh34DdpmFTwNlRpnQOQc419M3zP9kt4r1geNlaCIM1Q4uVsvDJheZOgVJwpDvsD9bzurVb1wCFAec5wNb24KxZ-00OECRHNGu2VSuNTOgc-m7-KH8ZgCOzw0vBqQzIRRGdM8EAPrSrERctiIj_aNAYlDvVp2im4kwBY")'}}></div>
             <h2 className="text-xl font-bold text-gray-900">Hermione Granger</h2>
             <p className="text-text-secondary">Advanced Potion-Making</p>
             <div className="flex items-center gap-2 mt-2 text-sm text-gray-500">
                <span className="material-symbols-outlined text-base">calendar_today</span>
                Submitted: 15 Oct 2023
             </div>
          </div>
       </aside>

       <main className="flex-1 ml-[25%] p-8 bg-white min-h-screen">
          <div className="max-w-3xl mx-auto">
             <div className="flex border-b border-gray-200 mb-8">
                <button className="px-6 py-3 border-b-2 border-primary text-primary font-medium">Interview Transcript</button>
                <button className="px-6 py-3 text-gray-500 hover:text-gray-700">Original Essay</button>
                <button className="px-6 py-3 text-gray-500 hover:text-gray-700">Feedback Editor</button>
             </div>

             <div className="space-y-8">
                <div className="space-y-2">
                   <p className="text-sm font-medium text-gray-500">AI Interviewer</p>
                   <div className="bg-gray-50 p-5 rounded-lg text-gray-800 leading-relaxed">
                     Good morning, Hermione. Thank you for submitting your essay on the properties of moonstone. Let’s begin. Can you elaborate on your primary argument regarding its use in calming draughts?
                   </div>
                </div>

                <div className="space-y-2">
                   <p className="text-sm font-medium text-gray-500 text-right">Hermione Granger</p>
                   <div className="bg-primary/5 p-5 rounded-lg text-gray-800 leading-relaxed border border-primary/10">
                     Of course. My central thesis is that the calming properties of moonstone are not solely magical, but are amplified by its chemical composition, specifically its silicate structure. This structure interacts with potion ingredients like syrup of hellebore at a molecular level to stabilize the volatile compounds, resulting in a more potent and longer-lasting calming effect than previously documented in texts like 'Magical Drafts and Potions'.
                   </div>
                </div>

                <div className="space-y-2">
                   <p className="text-sm font-medium text-gray-500">AI Interviewer</p>
                   <div className="bg-gray-50 p-5 rounded-lg text-gray-800 leading-relaxed">
                     That's a fascinating point. Your essay mentions Gringott's 1742 study. How does your research challenge or build upon those findings?
                   </div>
                </div>

                <div className="space-y-2">
                   <p className="text-sm font-medium text-gray-500 text-right">Hermione Granger</p>
                   <div className="bg-primary/5 p-5 rounded-lg text-gray-800 leading-relaxed border border-primary/10">
                     The 1742 study correctly identified moonstone's efficacy but attributed it purely to its lunar affinity. My research builds upon that by providing a scientific framework. While the lunar cycle does influence its magical potency, I argue that the base efficacy is rooted in its physical properties. It's an instance where Muggle science—or what we would call alchemy's physical principles—can explain a magical phenomenon, suggesting a greater overlap than wizarding tradition often acknowledges.
                   </div>
                </div>
             </div>

             <div className="mt-12 flex justify-end gap-4 border-t border-gray-100 pt-6">
                 <button className="px-6 py-2.5 bg-gray-100 text-gray-700 font-medium rounded-lg hover:bg-gray-200">Save Feedback</button>
                 <button className="px-6 py-2.5 bg-primary text-white font-medium rounded-lg hover:bg-blue-600">Submit Grade</button>
             </div>
          </div>
       </main>
    </div>
  );
};