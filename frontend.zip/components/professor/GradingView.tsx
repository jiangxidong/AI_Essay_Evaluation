import React from 'react';
import { Link } from 'react-router-dom';

export const GradingView = () => {
  return (
    <div className="min-h-screen bg-background-light flex">
      {/* Sidebar */}
      <aside className="w-64 bg-white border-r border-gray-200 flex flex-col fixed h-full z-10">
         <div className="p-6">
            <div className="flex items-center gap-3 mb-8">
               <div className="w-8 h-8 rounded-lg bg-primary flex items-center justify-center text-white">
                  <span className="material-symbols-outlined text-xl">school</span>
               </div>
               <span className="font-bold text-gray-700">AcademiaGrade</span>
            </div>
            
            <nav className="space-y-2">
               <a href="#" className="flex items-center gap-3 px-3 py-2 text-text-secondary rounded-lg hover:bg-gray-50">
                  <span className="material-symbols-outlined">dashboard</span>
                  <span className="text-sm font-medium">Dashboard</span>
               </a>
               <Link to="/professor/dashboard" className="flex items-center gap-3 px-3 py-2 text-text-secondary rounded-lg hover:bg-gray-50">
                  <span className="material-symbols-outlined">groups</span>
                  <span className="text-sm font-medium">Students</span>
               </Link>
               <div className="flex items-center gap-3 px-3 py-2 bg-primary/10 text-primary rounded-lg">
                  <span className="material-symbols-outlined fill">assignment</span>
                  <span className="text-sm font-bold">Assessments</span>
               </div>
            </nav>
         </div>
         
         <div className="mt-auto p-4 border-t border-gray-200">
            <div className="flex items-center gap-3">
               <div className="w-10 h-10 rounded-full bg-cover bg-center" style={{backgroundImage: 'url("https://lh3.googleusercontent.com/aida-public/AB6AXuD7V7i1CH5AMIXVqVOoir9VwKrelKW-qopP7onQ2_FbTKiQLATRE8r3Tw16Ila912QTRSvw4ZFfd0Z9Aun5k-VqsGCnJaF29ylVPs3aW5RiaVLq4FAq0jOAd9jAWX-Ovsjhw8pD8Wjd_AuLrijH1L2lAnNWwp6pbE0LwQl6F9rEq5cYjLBBribOunBnCqtTrNl7vMnCDZy30AkwxVVheQ2SgdvMKnFu8G9gELva02lnwUUw9GlbWWgYwE8MS_cPKssUkcEobUzkSBxO")'}}></div>
               <div>
                  <p className="text-sm font-medium text-gray-900">Dr. Eleanor Vance</p>
                  <p className="text-xs text-text-secondary">Professor of History</p>
               </div>
            </div>
         </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 ml-64 p-8">
        <div className="max-w-4xl mx-auto">
           {/* Breadcrumbs */}
           <div className="flex items-center gap-2 text-sm text-text-secondary mb-6">
              <span>Assessments</span>
              <span>/</span>
              <span>History 101 Essays</span>
              <span>/</span>
              <span className="text-gray-900 font-medium">John Doe</span>
           </div>

           <div className="flex justify-between items-start mb-8">
              <div>
                 <h1 className="text-3xl font-bold text-gray-900 mb-1">John Doe - Essay Comprehension Review</h1>
                 <p className="text-text-secondary">History 101: The Renaissance Period</p>
              </div>
              <div className="flex gap-3">
                 <button className="px-4 py-2 bg-white border border-gray-200 text-gray-700 font-bold text-sm rounded-lg hover:bg-gray-50">Add General Feedback</button>
                 <button className="px-4 py-2 bg-primary text-white font-bold text-sm rounded-lg hover:bg-blue-600">Submit Final Grade</button>
              </div>
           </div>

           {/* Score Cards */}
           <div className="grid grid-cols-3 gap-4 mb-8">
              <div className="bg-white p-6 rounded-lg border border-gray-200">
                 <p className="text-gray-700 font-medium mb-2">Overall Score</p>
                 <div className="flex items-baseline gap-2">
                    <span className="text-3xl font-bold text-gray-900">82%</span>
                    <span className="text-sm font-medium text-green-600">+5%</span>
                 </div>
              </div>
              <div className="bg-white p-6 rounded-lg border border-gray-200">
                 <p className="text-gray-700 font-medium mb-2">Comprehension</p>
                 <div className="flex items-baseline gap-2">
                    <span className="text-3xl font-bold text-gray-900">A-</span>
                    <span className="text-sm font-medium text-green-600">+2%</span>
                 </div>
              </div>
              <div className="bg-white p-6 rounded-lg border border-gray-200">
                 <p className="text-gray-700 font-medium mb-2">Clarity</p>
                 <div className="flex items-baseline gap-2">
                    <span className="text-3xl font-bold text-gray-900">B+</span>
                    <span className="text-sm font-medium text-red-600">-1%</span>
                 </div>
              </div>
           </div>

           {/* Questions */}
           <div className="space-y-6">
              {[
                  {
                      q: "Q1",
                      text: "Analyze the primary factors that led to the decline of the feudal system in Europe.",
                      answer: "The decline of the feudal system was a multifaceted process driven by economic shifts, such as the growth of a market economy and the rise of towns, which offered peasants alternative livelihoods. The Black Death also played a crucial role by drastically reducing the population...",
                      score: "16/20",
                      color: "green"
                  },
                  {
                      q: "Q2",
                      text: "Discuss the impact of the printing press on the Renaissance and the Protestant Reformation.",
                      answer: "Gutenberg's printing press revolutionized communication, enabling the rapid dissemination of ideas. During the Renaissance, it facilitated the spread of classical texts and humanist thought...",
                      score: "18/20",
                      color: "green"
                  },
                  {
                      q: "Q3",
                      text: "Explain the concept of 'mercantilism' and its role in European colonization.",
                      answer: "Mercantilism was an economic theory that a nation's wealth was measured by its holdings of gold and silver. This led to policies aimed at maximizing exports and minimizing imports...",
                      score: "13/20",
                      color: "orange"
                  },
                   {
                      q: "Q4",
                      text: "Describe the main artistic innovations of the High Renaissance, citing at least two key artists.",
                      answer: "The High Renaissance saw artists achieve a new level of realism and emotional depth. Key innovations included the mastery of perspective...",
                      score: "10/20",
                      color: "red"
                  }
              ].map((item, idx) => (
                  <div key={idx} className="bg-white p-6 rounded-lg border border-gray-200 flex gap-4">
                     <div className="flex-1 flex gap-4">
                        <div className="shrink-0 w-8 h-8 bg-primary text-white rounded-full flex items-center justify-center font-bold text-sm">{item.q}</div>
                        <div>
                           <p className="text-lg font-medium text-gray-800 mb-4">{item.text}</p>
                           <div className="pl-4 border-l-4 border-blue-100">
                              <p className="text-gray-600 italic">{item.answer}</p>
                           </div>
                        </div>
                     </div>
                     <div className={`font-bold text-xl text-${item.color}-600`}>{item.score}</div>
                  </div>
              ))}
           </div>
        </div>
      </main>
    </div>
  );
};
