export interface User {
  id: string;
  name: string;
  role: 'student' | 'professor';
  avatar: string;
}

export interface Assignment {
  id: string;
  courseCode: string;
  title: string;
  dueDate: string;
  status: 'submitted' | 'late' | 'overdue' | 'not-started' | 'feedback-available' | 'graded';
  interviewStatus?: 'scheduled' | 'pending' | 'complete' | 'not-scheduled';
  score?: number;
  maxScore?: number;
  submittedCount?: number;
  totalStudents?: number;
  pendingReviewCount?: number;
}

export interface StudentSubmission {
  id: string;
  studentName: string;
  studentAvatar: string;
  submissionStatus: 'submitted' | 'late';
  interviewStatus: 'scheduled' | 'not-scheduled' | 'pending' | 'complete';
  aiScore: number;
  reviewStatus: 'pending-review' | 'graded';
  submittedDate: string;
}

export interface InterviewMessage {
  id: string;
  speaker: 'AI Interviewer' | 'Student';
  text: string;
}
