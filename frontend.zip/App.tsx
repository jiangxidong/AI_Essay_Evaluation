import React, { useState } from 'react';
import { HashRouter, Routes, Route, Navigate, useLocation, Link } from 'react-router-dom';
import { StudentDashboard } from './components/student/StudentDashboard';
import { InterviewScreen } from './components/student/InterviewScreen';
import { UploadEssay } from './components/student/UploadEssay';
import { FeedbackView } from './components/student/FeedbackView';
import { InterviewFeedbackView } from './components/student/InterviewFeedbackView';
import { ProfessorDashboard } from './components/professor/ProfessorDashboard';
import { CourseView } from './components/professor/CourseView';
import { GradingView } from './components/professor/GradingView';
import { FeedbackEditor } from './components/professor/FeedbackEditor';
import { InterviewReview } from './components/professor/InterviewReview';

// Simple Navigation wrapper to mimic the "Persona" selection for the demo
const DemoNavigation = () => {
  const location = useLocation();
  const isStudent = location.pathname.startsWith('/student');
  const isProfessor = location.pathname.startsWith('/professor');

  if (location.pathname === '/' || location.pathname === '/select-persona') {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <div className="max-w-md w-full bg-white p-8 rounded-xl shadow-lg text-center">
          <div className="mb-8">
            <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-4">
              <span className="material-symbols-outlined text-3xl text-primary">school</span>
            </div>
            <h1 className="text-2xl font-bold text-gray-900">Veritas Academic</h1>
            <p className="text-gray-500 mt-2">Select your role to view the demo</p>
          </div>
          <div className="space-y-4">
            <Link to="/student/dashboard" className="block w-full py-4 px-6 bg-white border-2 border-primary/10 hover:border-primary rounded-xl transition-all group">
              <div className="flex items-center gap-4">
                <div className="w-10 h-10 rounded-full bg-blue-100 flex items-center justify-center text-blue-600">
                  <span className="material-symbols-outlined">person</span>
                </div>
                <div className="text-left">
                  <h3 className="font-bold text-gray-900 group-hover:text-primary">Student Portal</h3>
                  <p className="text-sm text-gray-500">Submit essays, take interviews, view grades</p>
                </div>
              </div>
            </Link>
            <Link to="/professor/dashboard" className="block w-full py-4 px-6 bg-white border-2 border-secondary/10 hover:border-secondary rounded-xl transition-all group">
              <div className="flex items-center gap-4">
                <div className="w-10 h-10 rounded-full bg-orange-100 flex items-center justify-center text-orange-600">
                  <span className="material-symbols-outlined">history_edu</span>
                </div>
                <div className="text-left">
                  <h3 className="font-bold text-gray-900 group-hover:text-secondary">Professor Portal</h3>
                  <p className="text-sm text-gray-500">Grade submissions, review AI analysis</p>
                </div>
              </div>
            </Link>
          </div>
        </div>
      </div>
    );
  }

  return null;
};

const App = () => {
  return (
    <HashRouter>
      <Routes>
        <Route path="/" element={<DemoNavigation />} />
        
        {/* Student Routes */}
        <Route path="/student/dashboard" element={<StudentDashboard />} />
        <Route path="/student/upload" element={<UploadEssay />} />
        <Route path="/student/interview" element={<InterviewScreen />} />
        <Route path="/student/feedback/essay" element={<FeedbackView />} />
        <Route path="/student/feedback/interview" element={<InterviewFeedbackView />} />

        {/* Professor Routes */}
        <Route path="/professor/dashboard" element={<ProfessorDashboard />} />
        <Route path="/professor/course/:id" element={<CourseView />} />
        <Route path="/professor/grade/:studentId" element={<GradingView />} />
        <Route path="/professor/edit-feedback/:studentId" element={<FeedbackEditor />} />
        <Route path="/professor/review-interview/:studentId" element={<InterviewReview />} />

        {/* Fallback */}
        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>
    </HashRouter>
  );
};

export default App;
